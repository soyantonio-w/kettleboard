# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['kettlebrand']

package_data = \
{'': ['*']}

install_requires = \
['google-api-python-client>=1.9.3,<2.0.0',
 'google-cloud-bigquery>=1.25.0,<2.0.0']

setup_kwargs = {
    'name': 'kettlebrand',
    'version': '0.1.0',
    'description': 'Creating my first package',
    'long_description': None,
    'author': 'Demo',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
